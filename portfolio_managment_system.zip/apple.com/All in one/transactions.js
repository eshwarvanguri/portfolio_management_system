document.addEventListener('DOMContentLoaded', () => {
    // Add New Transaction
    document.getElementById('addTransaction').addEventListener('click', () => {
        // Implement add transaction logic here
        alert('Add New Transaction clicked');
    });
});
